# WD-201-L2-MILESTONE
Level 2 milestone was related to a home webpage >> projects>> opens registration form of WD 101 capstone project
